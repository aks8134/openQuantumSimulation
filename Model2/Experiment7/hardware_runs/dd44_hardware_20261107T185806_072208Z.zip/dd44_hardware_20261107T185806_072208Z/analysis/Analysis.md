# Model2 Experiment7 hardware DD comparison

4 paired paths, 256 shots per basis/arm; 1 jobs.
Errors below compare each measured ensemble to the ideal ensemble of those exact saved paths.

| Observable | baseline | dd_ratio_2 | dd_ratio_10 |
| --- | ---: | ---: | ---: |
| populations | 0.15475 | 0.110805 | 0.0942031 |
| excitation_flows | 0.033915 | 0.024257 | 0.0206301 |

Direct DD-policy contrasts and comparisons to baseline are in observables.csv, with shot and descriptive paired-path SE vectors.
Combined maximum errors and RMSEs are in method_errors.csv. Error differences in error_comparisons.csv are treatment minus reference; negative favors treatment in this observed sample.
These error rankings are descriptive: maximum-error differences do not have confidence intervals, and a small pilot does not establish a statistically decisive winner.

All compared non-X server timing anchors equal: **True**.
Compiler-returned added X pulse counts match construction: **True**.
A timing mismatch needs inspection before attributing a change to DD alone.
Job-local zero/one/half-mixture diagnostics and uncertainty vectors are in analysis.json; no correction or job exclusion applied.
Currents in the table are divided by J. Small pilots do not establish the full-run 0.02 tolerance.
