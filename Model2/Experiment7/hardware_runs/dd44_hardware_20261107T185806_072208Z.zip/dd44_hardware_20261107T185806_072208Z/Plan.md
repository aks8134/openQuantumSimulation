# Model2 Experiment7: schedule-first dynamical decoupling

Stage: **paired**; backend `ibm_phoenix`; physical path `[38, 48, 47, 57, 56, 66, 76, 86, 96, 97, 98, 108]`.
Frozen Model2: N=10, J=1, Γ/J=2, equal reservoirs p=.25, half-mixed, 44-step warped cosine.
First 4 fixed seed-29 trajectories; all three bases z/xy/yx.
Arms: ['baseline', 'dd_ratio_2', 'dd_ratio_10']; 256 shots per trajectory/basis/arm; 2048 per control/arm/job.
**1 jobs, 45 circuits, 27,648 total shots.**

Preparation/measurement/reservoir physics and all 44 resets retained. Runtime automatic DD and twirling disabled.
DD-off is ALAP scheduled with delays. The paired experiment adds inspected system-only XX inside fitting local block idle windows.
Each job includes zero, one and held-out half-mixture Z controls for each arm. Controls diagnose preparation/readout, not full-depth DD fidelity.
Published instruction/execution limits counted at 80% instruction allowance. These counts do not establish compiler acceptance or QPU cost.
The compiler-returned timing is the visualization source; no timeline_drawer or synthetic schedule fallback.
Cloud dry-run outputs are random mock counts and cannot measure DD performance. Hardware counts are analyzed only from an explicit hardware submission.
Small scouts/pilots do not certify the 0.02 target or the full 16384-path experiment. No QPU jobs are submitted by preparation.

`dd_ratio_2`: XX, minimum idle ratio 2; physical idle cutoff >0.16..0.16 us on the selected sites.
`dd_ratio_10`: XX, minimum idle ratio 10; physical idle cutoff >0.8..0.8 us on the selected sites.